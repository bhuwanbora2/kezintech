import React from 'react';
import ClaimForm from '../components/ClaimForm';
import CaseReviewCard from '../components/CaseReviewCard';
import MesotheliomaInfo from '../components/MesotheliomaInfo';
import TimeDisplay from '../components/TimeDisplay';

const Index = () => {
  return (
    <div className="min-h-screen py-8 px-4 relative">
      <TimeDisplay />
      
      {/* Desktop Layout */}
      <div className="hidden lg:flex items-center justify-center min-h-screen gap-8 max-w-6xl mx-auto">
        <div className="flex flex-col gap-8">
          <CaseReviewCard />
          <MesotheliomaInfo />
        </div>
        <div className="flex-shrink-0">
          <ClaimForm />
        </div>
      </div>

      {/* Mobile Layout */}
      <div className="lg:hidden flex flex-col items-center gap-6 max-w-sm mx-auto">
        <div className="flex gap-4 w-full">
          <div className="flex-1">
            <CaseReviewCard />
          </div>
        </div>
        <MesotheliomaInfo />
        <ClaimForm />
      </div>
    </div>
  );
};

export default Index;

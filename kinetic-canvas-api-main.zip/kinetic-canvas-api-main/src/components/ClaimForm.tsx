import React, { useState } from 'react';
import { Calendar, ChevronDown } from 'lucide-react';

interface FormData {
  firstName: string;
  lastName: string;
  phoneNumber: string;
  email: string;
  dateOfBirth: string;
  jobTitle: string;
  dateOfDiagnosis: string;
  typeOfDiagnosis: string;
  story: string;
}

const ClaimForm = () => {
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    phoneNumber: '',
    email: '',
    dateOfBirth: '',
    jobTitle: '',
    dateOfDiagnosis: '',
    typeOfDiagnosis: '',
    story: '',
  });

  const [agreedToPrivacy, setAgreedToPrivacy] = useState(false);
  const [verifyPerson, setVerifyPerson] = useState(false);

  const diagnosisTypes = [
    'Mesothelioma',
    'Lung Cancer',
    'Asbestosis',
    'Pleural Disease',
    'Other'
  ];

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!agreedToPrivacy || !verifyPerson) {
      alert('Please agree to the privacy policy and verify you are a person.');
      return;
    }
    
    // Form submission logic here
    console.log('Form submitted:', formData);
    alert('Your claim has been submitted successfully!');
  };

  return (
    <div className="card-professional p-6 w-full max-w-md mx-auto">
      <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">Claim Form</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <input
              type="text"
              name="firstName"
              placeholder="First Name *"
              value={formData.firstName}
              onChange={handleInputChange}
              className="form-input-professional"
              required
            />
          </div>
          <div>
            <input
              type="text"
              name="lastName"
              placeholder="Last Name *"
              value={formData.lastName}
              onChange={handleInputChange}
              className="form-input-professional"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <input
              type="tel"
              name="phoneNumber"
              placeholder="Phone Number *"
              value={formData.phoneNumber}
              onChange={handleInputChange}
              className="form-input-professional"
              required
            />
          </div>
          <div>
            <input
              type="email"
              name="email"
              placeholder="Email ID *"
              value={formData.email}
              onChange={handleInputChange}
              className="form-input-professional"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="relative">
            <input
              type="date"
              name="dateOfBirth"
              placeholder="Date of Birth *"
              value={formData.dateOfBirth}
              onChange={handleInputChange}
              className="form-input-professional"
              required
            />
            <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
          </div>
          <div>
            <input
              type="text"
              name="jobTitle"
              placeholder="Job Title *"
              value={formData.jobTitle}
              onChange={handleInputChange}
              className="form-input-professional"
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="relative">
            <input
              type="date"
              name="dateOfDiagnosis"
              placeholder="Date of Diagnosis *"
              value={formData.dateOfDiagnosis}
              onChange={handleInputChange}
              className="form-input-professional"
              required
            />
            <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
          </div>
          <div className="relative">
            <select
              name="typeOfDiagnosis"
              value={formData.typeOfDiagnosis}
              onChange={handleInputChange}
              className="form-input-professional appearance-none"
              required
            >
              <option value="">Type of Diagnosis *</option>
              {diagnosisTypes.map((type) => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4 pointer-events-none" />
          </div>
        </div>

        <div>
          <textarea
            name="story"
            placeholder="Tell us your story (optional)"
            value={formData.story}
            onChange={handleInputChange}
            className="form-input-professional min-h-[100px] resize-vertical"
            rows={4}
          />
        </div>

        <div className="space-y-3 text-sm">
          <label className="flex items-start space-x-3 cursor-pointer">
            <input
              type="checkbox"
              checked={agreedToPrivacy}
              onChange={(e) => setAgreedToPrivacy(e.target.checked)}
              className="mt-1 w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded focus:ring-primary focus:ring-2"
              required
            />
            <span className="text-gray-600 leading-relaxed">
              I agree to the privacy policy and disclaimer and give my express written 
              consent to be contacted regarding my case options. I understand that I may 
              be contacted by phone, text, or email and that any consent does not require purchase. This is Legal advertising
            </span>
          </label>

          <label className="flex items-center space-x-3 cursor-pointer">
            <input
              type="checkbox"
              checked={verifyPerson}
              onChange={(e) => setVerifyPerson(e.target.checked)}
              className="w-4 h-4 text-primary bg-gray-100 border-gray-300 rounded focus:ring-primary focus:ring-2"
              required
            />
            <span className="text-gray-600">
              Please check this box to verify you're a person.
            </span>
          </label>
        </div>

        <button
          type="submit"
          className="btn-professional w-full mt-6 text-lg"
        >
          Submit →
        </button>
      </form>
    </div>
  );
};

export default ClaimForm;
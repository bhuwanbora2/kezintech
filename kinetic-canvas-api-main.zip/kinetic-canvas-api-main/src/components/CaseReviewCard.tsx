import React from 'react';
import { Shield, DollarSign, FileText } from 'lucide-react';

const CaseReviewCard = () => {
  return (
    <div className="card-professional p-6 w-full max-w-sm mx-auto">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Free</h2>
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Case</h3>
        <h4 className="text-2xl font-bold text-gray-800 mb-4">Review</h4>
        
        <div className="flex justify-center mb-6">
          <div className="badge-circular">
            <span className="text-xs leading-tight">ONLY<br/>50%<br/>LET</span>
          </div>
        </div>
      </div>

      <div className="space-y-4 mb-6">
        <div className="flex items-center space-x-3">
          <Shield className="w-5 h-5 text-primary flex-shrink-0" />
          <span className="text-gray-700 text-sm">100% Confidential</span>
        </div>
        
        <div className="flex items-center space-x-3">
          <DollarSign className="w-5 h-5 text-primary flex-shrink-0" />
          <span className="text-gray-700 text-sm">No Win, No Fee</span>
        </div>
        
        <div className="flex items-center space-x-3">
          <FileText className="w-5 h-5 text-primary flex-shrink-0" />
          <span className="text-gray-700 text-sm">Free Case Evaluation</span>
        </div>
      </div>

      <div className="text-center">
        <button className="btn-secondary">
          Contact us
        </button>
      </div>

      <div className="text-center mt-4 text-xs text-gray-500">
        We are here<br />to help!
      </div>
    </div>
  );
};

export default CaseReviewCard;
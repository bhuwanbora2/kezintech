import React, { useState, useEffect } from 'react';

const TimeDisplay = () => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: false
    });
  };

  return (
    <div className="fixed top-4 right-4 bg-white/10 backdrop-blur-md rounded-lg px-3 py-1 text-white font-mono text-sm">
      {formatTime(currentTime)}
    </div>
  );
};

export default TimeDisplay;
import React from 'react';
import { Heart, AlertTriangle, Scale } from 'lucide-react';

const MesotheliomaInfo = () => {
  return (
    <div className="card-professional p-6 w-full max-w-sm mx-auto">
      <div className="flex items-center space-x-3 mb-4">
        <Heart className="w-6 h-6 text-red-500" />
        <h3 className="text-lg font-bold text-gray-800">
          Have you or a loved one been affected by Mesothelioma?
        </h3>
      </div>

      <p className="text-gray-700 text-sm mb-4 leading-relaxed">
        As a woman, you've carried the weight of care, love, and resilience. 
        Now it's time someone stands with you.
      </p>

      <div className="space-y-3 mb-6">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
          <span className="text-gray-700 text-sm">
            Secondary Asbestos exposure is common
          </span>
        </div>
        
        <div className="flex items-start space-x-3">
          <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
          <span className="text-gray-700 text-sm">
            Misdiagnosis delays are more frequent in women
          </span>
        </div>
        
        <div className="flex items-start space-x-3">
          <Scale className="w-4 h-4 text-blue-500 mt-0.5 flex-shrink-0" />
          <span className="text-gray-700 text-sm">
            Women have won significant legal settlements
          </span>
        </div>
      </div>
    </div>
  );
};

export default MesotheliomaInfo;